import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '15mb' }));

// Verified available models in this Google AI Studio project
export const VERIFIED_MODELS = [
  { id: 'gemini-flash-lite-latest', name: 'Gemini Flash-Lite Latest', description: 'Recommended · High Quota & Sub-second Latency', isDefault: true },
  { id: 'gemini-3.5-flash', name: 'Gemini 3.5 Flash', description: 'High Quota & Rich Capabilities', isDefault: false },
  { id: 'gemini-3.5-flash-lite', name: 'Gemini 3.5 Flash Lite', description: 'Lightweight & Efficient', isDefault: false },
  { id: 'gemini-3.1-flash-lite', name: 'Gemini 3.1 Flash Lite', description: 'Stable Flash Lite', isDefault: false },
  { id: 'gemini-3.8-flash', name: 'Gemini 3.8 Flash', description: 'Preview (Strict 20 RPD Free Quota)', isDefault: false },
];

export const DEFAULT_MODEL_ID = 'gemini-flash-lite-latest';

// Track exhausted models in memory to avoid repeated requests to exhausted daily quotas
const exhaustedModels = new Map<string, number>(); // model -> timestamp when it was exhausted
const EXHAUSTION_CACHE_MS = 60 * 60 * 1000; // 1 hour

function isModelExhausted(modelId: string): boolean {
  const timestamp = exhaustedModels.get(modelId);
  if (!timestamp) return false;
  if (Date.now() - timestamp > EXHAUSTION_CACHE_MS) {
    exhaustedModels.delete(modelId);
    return false;
  }
  return true;
}

function markModelExhausted(modelId: string) {
  exhaustedModels.set(modelId, Date.now());
}

// Distinguish temporary rate limits from exhausted daily quotas
interface RateLimitAnalysis {
  isRateLimit: boolean;
  isDailyQuotaExhausted: boolean;
  retryDelaySeconds: number | null;
}

function analyzeRateLimit(error: any): RateLimitAnalysis {
  const errStr = String(error?.message || '');
  const status = error?.status || error?.code;
  const is429 =
    status === 429 ||
    errStr.includes('429') ||
    errStr.includes('RESOURCE_EXHAUSTED') ||
    errStr.includes('Quota exceeded');

  if (!is429) {
    return { isRateLimit: false, isDailyQuotaExhausted: false, retryDelaySeconds: null };
  }

  // Check if daily quota
  const isDaily =
    errStr.includes('PerDay') ||
    errStr.includes('requests_per_day') ||
    errStr.includes('daily') ||
    errStr.includes('GenerateRequestsPerDay');

  // Extract retry delay if available
  let retrySeconds: number | null = null;
  const match = errStr.match(/retry in\s+([0-9.]+)\s*s/i) || errStr.match(/"retryDelay":\s*"([0-9]+)s"/i);
  if (match) {
    retrySeconds = parseFloat(match[1]);
  }

  return {
    isRateLimit: true,
    isDailyQuotaExhausted: isDaily || (retrySeconds !== null && retrySeconds > 30),
    retryDelaySeconds: retrySeconds,
  };
}

export function formatGeminiErrorMessage(error: any): string {
  if (!error) return 'An unexpected error occurred.';
  let raw = error.message || String(error);

  try {
    if (typeof raw === 'string' && raw.trim().startsWith('{')) {
      const parsed = JSON.parse(raw);
      if (parsed?.error?.message) {
        raw = parsed.error.message;
        if (typeof raw === 'string' && raw.trim().startsWith('{')) {
          const subParsed = JSON.parse(raw);
          if (subParsed?.error?.message) raw = subParsed.error.message;
        }
      }
    }
  } catch {}

  const analysis = analyzeRateLimit(error);
  if (analysis.isDailyQuotaExhausted) {
    return 'The project daily quota for this model is exhausted. Please switch to another model in Settings or try again tomorrow.';
  }
  if (analysis.isRateLimit) {
    const delayText = analysis.retryDelaySeconds ? ` in ${analysis.retryDelaySeconds}s` : ' shortly';
    return `Temporary rate limit reached. Please retry${delayText} or switch models in Settings.`;
  }

  return raw;
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function getGenAIClient(customKey?: string) {
  const apiKey = customKey?.trim() || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured on the server, nor was a client key provided.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check endpoint
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasKey: Boolean(process.env.GEMINI_API_KEY),
    defaultModel: DEFAULT_MODEL_ID,
    timestamp: new Date().toISOString(),
  });
});

// Dynamic model list endpoint
app.get('/api/models', (req: Request, res: Response) => {
  res.json({
    models: VERIFIED_MODELS,
    defaultModel: DEFAULT_MODEL_ID,
  });
});

const DEFAULT_SYSTEM_INSTRUCTION = 
  `You are MEER AI, an exceptionally smart, warm, intuitive, and versatile AI assistant created with the tagline "Your AI. Your Way."
You are fluent in English, Urdu (اردو), Roman Urdu (conversational Urdu written in the Latin alphabet, e.g. "Aap kaise hain? Main theek hoon."), Hindi (हिंदी), and Sindhi (سنڌي), among others.

Crucial Language & Tone Guidelines:
1. When addressed in Roman Urdu, respond naturally in fluid, authentic Roman Urdu without converting to formal Urdu script or English unless asked. Use natural colloquial phrases (e.g. "Bilkul!", "Haan zaroor", "Aapka kya sawaal hai?").
2. When addressed in Urdu (Nastaliq/Arabic script), Hindi (Devanagari), or Sindhi, respond in that authentic script with native warmth and cultural nuance.
3. When functioning as a language learning partner, provide encouraging conversation, gently note grammatical or vocabulary suggestions if appropriate, and keep dialogue engaging.
4. When writing code, provide clean, idiomatic code with clear explanations and language identifiers in markdown code fences.
5. Format your output cleanly with markdown (bold, lists, headings, tables, and code blocks). Avoid unnecessary boilerplate.`;

// Build fallback list starting with requested model, followed by verified models excluding known exhausted ones
function getModelFallbackOrder(requestedModel: string): string[] {
  const order = [
    requestedModel,
    DEFAULT_MODEL_ID,
    'gemini-flash-lite-latest',
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
  ];

  const unique = Array.from(new Set(order.filter(Boolean)));
  // Filter out models known to be daily exhausted, but keep requestedModel as first attempt if user selected it
  return unique.filter((m, idx) => idx === 0 || !isModelExhausted(m));
}

// SSE Streaming chat endpoint with intelligent rate-limit handling and verified model fallback
app.post('/api/chat/stream', async (req: Request, res: Response) => {
  const {
    messages,
    model = DEFAULT_MODEL_ID,
    temperature = 0.7,
    systemInstruction,
    clientApiKey,
  } = req.body;

  if (!Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({ error: 'Messages array is required and must not be empty.' });
    return;
  }

  let ai: GoogleGenAI;
  try {
    const customKey = (req.headers['x-gemini-api-key'] as string) || clientApiKey;
    ai = getGenAIClient(customKey);
  } catch (err: any) {
    res.status(401).json({ error: err.message || 'API key missing.' });
    return;
  }

  const formattedContents = messages.map((m: { role: string; content: string }) => ({
    role: m.role === 'user' ? 'user' : 'model',
    parts: [{ text: m.content }],
  }));

  const effectiveSystemInstruction = systemInstruction?.trim()
    ? `${DEFAULT_SYSTEM_INSTRUCTION}\n\nUser Custom Persona / Instructions:\n${systemInstruction.trim()}`
    : DEFAULT_SYSTEM_INSTRUCTION;

  const candidateModels = getModelFallbackOrder(model);

  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();
  (res as any).socket?.setNoDelay?.(true);

  let isAborted = false;
  res.on('close', () => {
    if (!res.writableEnded) {
      isAborted = true;
    }
  });

  let streamSucceeded = false;
  let lastError: any = null;
  let activeModelUsed = '';

  for (const candidateModel of candidateModels) {
    if (isAborted) break;

    let modelAttempt = 0;
    const maxAttemptsForThisModel = 2; // At most 1 retry if short burst rate limit

    while (modelAttempt < maxAttemptsForThisModel) {
      if (isAborted) break;
      modelAttempt++;

      try {
        const responseStream = await ai.models.generateContentStream({
          model: candidateModel,
          contents: formattedContents,
          config: {
            systemInstruction: effectiveSystemInstruction,
            temperature: Math.min(Math.max(Number(temperature) || 0.7, 0), 1),
          },
        });

        activeModelUsed = candidateModel;

        for await (const chunk of responseStream) {
          if (isAborted) break;
          const text = chunk.text;
          if (text) {
            res.write(`data: ${JSON.stringify({ text, model: candidateModel })}\n\n`);
            (res as any).flush?.();
          }
        }

        streamSucceeded = true;
        break; // Stream completed for this model
      } catch (error: any) {
        lastError = error;
        const analysis = analyzeRateLimit(error);

        if (analysis.isDailyQuotaExhausted) {
          console.warn(`[Quota Exhausted] Model ${candidateModel} reached daily limit. Marking exhausted and failing over.`);
          markModelExhausted(candidateModel);
          break; // Do not retry this model; jump immediately to next candidate model
        } else if (analysis.isRateLimit && analysis.retryDelaySeconds && analysis.retryDelaySeconds <= 8 && modelAttempt === 1 && !isAborted) {
          const waitMs = Math.ceil(analysis.retryDelaySeconds * 1000) + 400;
          console.log(`[Rate Limit Burst] Model ${candidateModel} asked to retry in ${analysis.retryDelaySeconds}s. Waiting ${waitMs}ms before 1 retry...`);
          await delay(waitMs);
          continue; // Retry this model once
        } else if (analysis.isRateLimit) {
          console.warn(`[Rate Limit] Model ${candidateModel} rate-limited. Moving to fallback model.`);
          break;
        } else {
          console.error(`[Error] Non-rate-limit error on ${candidateModel}:`, error?.message || error);
          break;
        }
      }
    }

    if (streamSucceeded) {
      break;
    }
  }

  if (isAborted) {
    return;
  }

  if (streamSucceeded) {
    res.write(`data: [DONE]\n\n`);
    res.end();
  } else {
    console.error('All available models exhausted or failed:', lastError);
    const friendlyMessage = formatGeminiErrorMessage(lastError);
    res.write(`data: ${JSON.stringify({ error: friendlyMessage })}\n\n`);
    res.write(`data: [DONE]\n\n`);
    res.end();
  }
});

// Non-streaming chat endpoint with fallback
app.post('/api/chat', async (req: Request, res: Response) => {
  const {
    messages,
    model = DEFAULT_MODEL_ID,
    temperature = 0.7,
    systemInstruction,
    clientApiKey,
  } = req.body;

  try {
    const customKey = (req.headers['x-gemini-api-key'] as string) || clientApiKey;
    const ai = getGenAIClient(customKey);

    const formattedContents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content }],
    }));

    const candidateModels = getModelFallbackOrder(model);
    let lastError: any = null;
    let responseText = '';

    for (const candidateModel of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model: candidateModel,
          contents: formattedContents,
          config: {
            systemInstruction: systemInstruction || DEFAULT_SYSTEM_INSTRUCTION,
            temperature: Math.min(Math.max(Number(temperature) || 0.7, 0), 1),
          },
        });
        responseText = response.text || '';
        break;
      } catch (err: any) {
        lastError = err;
        const analysis = analyzeRateLimit(err);
        if (analysis.isDailyQuotaExhausted) {
          markModelExhausted(candidateModel);
        }
      }
    }

    if (responseText) {
      res.json({ text: responseText });
    } else {
      res.status(500).json({ error: formatGeminiErrorMessage(lastError) });
    }
  } catch (error: any) {
    console.error('Error in /api/chat:', error);
    res.status(500).json({
      error: formatGeminiErrorMessage(error),
    });
  }
});

// Speech synthesis endpoint
app.post('/api/speech/synthesize', async (req: Request, res: Response) => {
  const { text, voiceName = 'Zephyr', clientApiKey } = req.body;

  if (!text || typeof text !== 'string') {
    res.status(400).json({ error: 'Text is required for speech synthesis.' });
    return;
  }

  try {
    const customKey = (req.headers['x-gemini-api-key'] as string) || clientApiKey;
    const ai = getGenAIClient(customKey);

    const truncatedText = text.slice(0, 600);

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [{ text: truncatedText }],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: voiceName || 'Zephyr',
            },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      res.json({
        audioBase64: base64Audio,
        mimeType: 'audio/wav',
      });
    } else {
      res.status(500).json({ error: 'No audio data returned from model.' });
    }
  } catch (error: any) {
    console.error('TTS error:', error);
    res.status(500).json({ error: formatGeminiErrorMessage(error) });
  }
});

// Local development server only. On Vercel, api/index.ts exports the Express app
// as a serverless function, while Vercel serves the Vite build from dist.
async function startLocalServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MEER AI server listening on http://0.0.0.0:${PORT}`);
  });
}

// Vercel provides VERCEL=1. Do not call listen() inside a serverless function.
if (!process.env.VERCEL) {
  startLocalServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}
