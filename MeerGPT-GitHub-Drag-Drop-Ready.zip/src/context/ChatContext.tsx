import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
  ReactNode,
} from 'react';
import { Conversation, Message, AppSettings, ThemeMode } from '../types';
import { speakText, stopSpeaking } from '../utils/speech';

interface ChatContextType {
  conversations: Conversation[];
  activeConversation: Conversation | null;
  activeId: string;
  isGenerating: boolean;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  settings: AppSettings;
  updateSettings: (partial: Partial<AppSettings>) => void;
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  toggleTheme: () => void;
  isSidebarOpen: boolean;
  setIsSidebarOpen: (open: boolean | ((prev: boolean) => boolean)) => void;
  isSettingsOpen: boolean;
  setIsSettingsOpen: (open: boolean) => void;
  isVoiceModeOpen: boolean;
  setIsVoiceModeOpen: (open: boolean) => void;
  createNewChat: () => void;
  selectConversation: (id: string) => void;
  deleteConversation: (id: string) => void;
  renameConversation: (id: string, newTitle: string) => void;
  clearAllConversations: () => void;
  exportConversations: () => void;
  exportAsMarkdown: (id?: string) => void;
  sendMessage: (content: string) => Promise<void>;
  stopGenerating: () => void;
  regenerateResponse: (messageId: string) => Promise<void>;
  editAndResend: (messageId: string, newContent: string) => Promise<void>;
}

const DEFAULT_SETTINGS: AppSettings = {
  model: 'gemini-flash-lite-latest',
  temperature: 0.7,
  persona: 'default',
  systemInstruction: '',
  autoSpeak: false,
  speechRate: 1.0,
  speechPitch: 1.0,
  voiceLanguage: 'auto',
  sendOnEnter: true,
  preferredLanguage: 'auto',
};

const ChatContext = createContext<ChatContextType | undefined>(undefined);

function createInitialConversation(): Conversation {
  return {
    id: 'conv-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
    title: 'New Chat',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    messages: [],
    persona: 'default',
  };
}

export const ChatProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    try {
      const stored = localStorage.getItem('meer_ai_conversations');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to load conversations from localStorage; recovering safely', e);
    }
    return [createInitialConversation()];
  });

  const [activeId, setActiveId] = useState<string>(() => {
    try {
      const storedId = localStorage.getItem('meer_ai_active_id');
      if (storedId) return storedId;
    } catch {}
    return conversations[0]?.id || '';
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const stored = localStorage.getItem('meer_ai_settings');
      if (stored) {
        const parsed = JSON.parse(stored);
        // Automatically migrate users to verified high-quota models
        if (parsed.model === 'gemini-3.8-flash' || parsed.model === 'gemini-2.5-flash' || !parsed.model) {
          parsed.model = 'gemini-flash-lite-latest';
        }
        return { ...DEFAULT_SETTINGS, ...parsed };
      }
    } catch {}
    return DEFAULT_SETTINGS;
  });

  const [theme, setTheme] = useState<ThemeMode>(() => {
    try {
      const storedTheme = localStorage.getItem('meer_ai_theme') as ThemeMode;
      if (storedTheme === 'light' || storedTheme === 'dark' || storedTheme === 'system') {
        return storedTheme;
      }
    } catch {}
    return 'dark';
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isVoiceModeOpen, setIsVoiceModeOpen] = useState(false);

  const abortControllerRef = useRef<AbortController | null>(null);

  // Sync theme with HTML class and system preference
  useEffect(() => {
    const root = document.documentElement;
    const applyDark = (isDark: boolean) => {
      if (isDark) {
        root.classList.add('dark');
        root.classList.remove('light');
      } else {
        root.classList.remove('dark');
        root.classList.add('light');
      }
    };

    if (theme === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      applyDark(mediaQuery.matches);
      const listener = (e: MediaQueryListEvent) => applyDark(e.matches);
      mediaQuery.addEventListener('change', listener);
      localStorage.setItem('meer_ai_theme', 'system');
      return () => mediaQuery.removeEventListener('change', listener);
    } else {
      applyDark(theme === 'dark');
      localStorage.setItem('meer_ai_theme', theme);
    }
  }, [theme]);

  // Sync conversations to localStorage safely
  useEffect(() => {
    try {
      localStorage.setItem('meer_ai_conversations', JSON.stringify(conversations));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [conversations]);

  // Sync activeId to localStorage
  useEffect(() => {
    if (activeId) {
      try {
        localStorage.setItem('meer_ai_active_id', activeId);
      } catch {}
    }
  }, [activeId]);

  // Sync settings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('meer_ai_settings', JSON.stringify(settings));
    } catch {}
  }, [settings]);

  const activeConversation = conversations.find((c) => c.id === activeId) || conversations[0] || null;

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const updateSettings = (partial: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...partial }));
  };

  const createNewChat = () => {
    stopGenerating();
    stopSpeaking();
    const newChat = createInitialConversation();
    setConversations((prev) => [newChat, ...prev]);
    setActiveId(newChat.id);
    setIsSidebarOpen(false);
  };

  const selectConversation = (id: string) => {
    stopGenerating();
    stopSpeaking();
    setActiveId(id);
    setIsSidebarOpen(false);
  };

  const deleteConversation = (id: string) => {
    stopSpeaking();
    setConversations((prev) => {
      const filtered = prev.filter((c) => c.id !== id);
      if (filtered.length === 0) {
        const fresh = createInitialConversation();
        setActiveId(fresh.id);
        return [fresh];
      }
      if (activeId === id) {
        setActiveId(filtered[0].id);
      }
      return filtered;
    });
  };

  const renameConversation = (id: string, newTitle: string) => {
    if (!newTitle.trim()) return;
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, title: newTitle.trim(), updatedAt: Date.now() } : c))
    );
  };

  const clearAllConversations = () => {
    stopGenerating();
    stopSpeaking();
    const fresh = createInitialConversation();
    setConversations([fresh]);
    setActiveId(fresh.id);
  };

  const exportConversations = () => {
    const cleanData = conversations.map((conv) => ({
      id: conv.id,
      title: conv.title,
      createdAt: new Date(conv.createdAt).toISOString(),
      updatedAt: new Date(conv.updatedAt).toISOString(),
      messages: conv.messages.map((m) => ({
        role: m.role,
        content: m.content,
        timestamp: new Date(m.timestamp).toISOString(),
      })),
    }));

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(cleanData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `meer_ai_chat_history_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const exportAsMarkdown = (targetId?: string) => {
    const conv = targetId ? conversations.find((c) => c.id === targetId) : activeConversation;
    if (!conv) return;

    let md = `# ${conv.title}\n*Exported from MEER AI on ${new Date().toLocaleDateString()}*\n\n---\n\n`;
    conv.messages.forEach((m) => {
      const sender = m.role === 'user' ? '👤 User' : '🤖 MEER AI';
      const time = new Date(m.timestamp).toLocaleTimeString();
      md += `### ${sender} (${time})\n\n${m.content}\n\n---\n\n`;
    });

    const dataStr = 'data:text/markdown;charset=utf-8,' + encodeURIComponent(md);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    const safeTitle = conv.title.replace(/[^a-z0-9_-]/gi, '_').toLowerCase();
    downloadAnchor.setAttribute('download', `meer_ai_${safeTitle}.md`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const stopGenerating = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsGenerating(false);
  };

  // Build effective system instruction based on persona & preferred language
  const getEffectiveSystemInstruction = () => {
    let custom = settings.systemInstruction?.trim() || '';

    if (settings.preferredLanguage && settings.preferredLanguage !== 'auto') {
      const langMap: Record<string, string> = {
        'roman-ur': 'The user prefers responses in Roman Urdu. Please respond in natural, friendly Roman Urdu.',
        'ur': 'The user prefers responses in Urdu (اردو script). Please respond in authentic Urdu.',
        'hi': 'The user prefers responses in Hindi (हिंदी script). Please respond in authentic Hindi.',
        'sd': 'The user prefers responses in Sindhi (سنڌي script). Please respond in authentic Sindhi.',
        'en': 'The user prefers responses in English.',
      };
      if (langMap[settings.preferredLanguage]) {
        custom = custom ? `${custom}\n${langMap[settings.preferredLanguage]}` : langMap[settings.preferredLanguage];
      }
    }

    return custom;
  };

  // Core stream runner
  const streamAIResponse = async (
    targetConvId: string,
    historyMessages: Message[],
    assistantMessageId: string
  ) => {
    setIsGenerating(true);
    abortControllerRef.current = new AbortController();

    let accumulatedText = '';

    try {
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(settings.customApiKey ? { 'x-gemini-api-key': settings.customApiKey } : {}),
        },
        body: JSON.stringify({
          messages: historyMessages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
          model: settings.model || 'gemini-3.8-flash',
          temperature: settings.temperature ?? 0.7,
          systemInstruction: getEffectiveSystemInstruction(),
          clientApiKey: settings.customApiKey,
        }),
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server returned error status ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) throw new Error('Response body is null or cannot be read.');

      const decoder = new TextDecoder('utf-8');
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || !trimmed.startsWith('data:')) continue;

          const dataPayload = trimmed.slice(5).trim();
          if (dataPayload === '[DONE]') {
            break;
          }

          try {
            const parsed = JSON.parse(dataPayload);
            if (parsed.text) {
              accumulatedText += parsed.text;
              setConversations((prev) =>
                prev.map((c) => {
                  if (c.id !== targetConvId) return c;
                  return {
                    ...c,
                    updatedAt: Date.now(),
                    messages: c.messages.map((m) =>
                      m.id === assistantMessageId ? { ...m, content: accumulatedText } : m
                    ),
                  };
                })
              );
            } else if (parsed.error) {
              throw new Error(parsed.error);
            }
          } catch (jsonErr: any) {
            // Tolerate non-JSON or partial chunks gracefully
          }
        }
      }

      // If finished and autoSpeak is true, speak the response
      if (settings.autoSpeak && accumulatedText.trim()) {
        speakText(accumulatedText, {
          rate: settings.speechRate,
          pitch: settings.speechPitch,
        });
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('Stream generation aborted by user.');
        // User stopped generation: preserve text received so far
      } else {
        console.error('Error generating AI response:', err);
        let cleanErr = err.message || 'Network error';
        try {
          if (typeof cleanErr === 'string' && cleanErr.trim().startsWith('{')) {
            const p = JSON.parse(cleanErr);
            if (p?.error?.message) cleanErr = p.error.message;
          }
        } catch {}
        if (cleanErr.includes('429') || cleanErr.includes('Quota exceeded') || cleanErr.includes('RESOURCE_EXHAUSTED')) {
          cleanErr = 'Gemini API free tier rate limit was reached. Please wait a few seconds and tap Retry, or select a different model in Settings.';
        }

        const errorMsg =
          accumulatedText.trim().length > 0
            ? `${accumulatedText}\n\n⚠️ *Generation interrupted: ${cleanErr}*`
            : `⚠️ **Unable to complete response:** ${cleanErr}`;

        setConversations((prev) =>
          prev.map((c) => {
            if (c.id !== targetConvId) return c;
            return {
              ...c,
              updatedAt: Date.now(),
              messages: c.messages.map((m) =>
                m.id === assistantMessageId
                  ? { ...m, content: errorMsg, isError: true }
                  : m
              ),
            };
          })
        );
      }
    } finally {
      setIsGenerating(false);
      abortControllerRef.current = null;
    }
  };

  const sendMessage = async (content: string) => {
    if (!content.trim() || isGenerating) return;

    stopSpeaking();
    const currentConv = activeConversation;
    if (!currentConv) return;

    const userMessage: Message = {
      id: 'msg-' + Date.now() + '-u',
      role: 'user',
      content: content.trim(),
      timestamp: Date.now(),
    };

    const assistantPlaceholderId = 'msg-' + (Date.now() + 1) + '-a';
    const assistantMessage: Message = {
      id: assistantPlaceholderId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
    };

    const updatedMessages = [...currentConv.messages, userMessage];

    // Determine smart title if first user message
    let newTitle = currentConv.title;
    if (currentConv.messages.length === 0 || currentConv.title === 'New Chat') {
      const preview = content.trim().replace(/\n+/g, ' ');
      newTitle = preview.length > 36 ? preview.slice(0, 36) + '...' : preview;
    }

    setConversations((prev) =>
      prev.map((c) =>
        c.id === currentConv.id
          ? {
              ...c,
              title: newTitle,
              updatedAt: Date.now(),
              messages: [...updatedMessages, assistantMessage],
            }
          : c
      )
    );

    await streamAIResponse(currentConv.id, updatedMessages, assistantPlaceholderId);
  };

  const regenerateResponse = async (messageId: string) => {
    if (isGenerating || !activeConversation) return;

    const msgIndex = activeConversation.messages.findIndex((m) => m.id === messageId);
    if (msgIndex === -1) return;

    // Cut messages up to the user query before this assistant response
    const targetMessage = activeConversation.messages[msgIndex];
    let history: Message[] = [];

    if (targetMessage.role === 'assistant') {
      history = activeConversation.messages.slice(0, msgIndex);
    } else {
      history = activeConversation.messages.slice(0, msgIndex + 1);
    }

    if (history.length === 0) return;

    const newAssistantId = 'msg-' + Date.now() + '-a';
    const newAssistantMessage: Message = {
      id: newAssistantId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
    };

    setConversations((prev) =>
      prev.map((c) => {
        if (c.id !== activeConversation.id) return c;
        return {
          ...c,
          updatedAt: Date.now(),
          messages: [...history, newAssistantMessage],
        };
      })
    );

    await streamAIResponse(activeConversation.id, history, newAssistantId);
  };

  const editAndResend = async (messageId: string, newContent: string) => {
    if (!newContent.trim() || isGenerating || !activeConversation) return;

    const msgIndex = activeConversation.messages.findIndex((m) => m.id === messageId);
    if (msgIndex === -1) return;

    const updatedUserMsg: Message = {
      ...activeConversation.messages[msgIndex],
      content: newContent.trim(),
      timestamp: Date.now(),
    };

    // Remove obsolete later messages and regenerate from edited point
    const historyBefore = activeConversation.messages.slice(0, msgIndex);
    const newHistory = [...historyBefore, updatedUserMsg];

    const newAssistantId = 'msg-' + Date.now() + '-a';
    const newAssistantMessage: Message = {
      id: newAssistantId,
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
    };

    setConversations((prev) =>
      prev.map((c) => {
        if (c.id !== activeConversation.id) return c;
        return {
          ...c,
          updatedAt: Date.now(),
          messages: [...newHistory, newAssistantMessage],
        };
      })
    );

    await streamAIResponse(activeConversation.id, newHistory, newAssistantId);
  };

  return (
    <ChatContext.Provider
      value={{
        conversations,
        activeConversation,
        activeId,
        isGenerating,
        searchQuery,
        setSearchQuery,
        settings,
        updateSettings,
        theme,
        setTheme,
        toggleTheme,
        isSidebarOpen,
        setIsSidebarOpen,
        isSettingsOpen,
        setIsSettingsOpen,
        isVoiceModeOpen,
        setIsVoiceModeOpen,
        createNewChat,
        selectConversation,
        deleteConversation,
        renameConversation,
        clearAllConversations,
        exportConversations,
        exportAsMarkdown,
        sendMessage,
        stopGenerating,
        regenerateResponse,
        editAndResend,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};
