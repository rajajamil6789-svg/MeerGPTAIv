export type Role = 'user' | 'assistant' | 'system';

export interface Message {
  id: string;
  role: Role;
  content: string;
  timestamp: number;
  isError?: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: Message[];
  persona?: PersonaType;
}

export type PersonaType = 
  | 'default' 
  | 'language-tutor' 
  | 'roman-urdu-expert' 
  | 'code-expert' 
  | 'creative';

export interface AppSettings {
  model: string;
  temperature: number;
  persona: PersonaType;
  systemInstruction: string;
  autoSpeak: boolean;
  speechRate: number;
  speechPitch: number;
  voiceLanguage: string;
  sendOnEnter: boolean;
  preferredLanguage: string;
  customApiKey?: string;
}

export type ThemeMode = 'dark' | 'light' | 'system';
