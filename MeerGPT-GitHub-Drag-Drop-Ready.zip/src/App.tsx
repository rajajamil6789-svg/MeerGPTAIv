/**
 * MEER AI - "Your AI. Your Way."
 * Production-ready ChatGPT-style conversational partner and assistant
 * supporting English, Urdu, Roman Urdu, Hindi, and Sindhi.
 */

import React from 'react';
import { ChatProvider } from './context/ChatContext';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';
import { VoiceModal } from './components/VoiceModal';
import { SettingsModal } from './components/SettingsModal';

function ChatLayout() {
  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-950 font-sans text-slate-100">
      <Sidebar />
      <main className="flex-1 flex flex-col h-full overflow-hidden relative">
        <ChatArea />
      </main>
      <VoiceModal />
      <SettingsModal />
    </div>
  );
}

export default function App() {
  return (
    <ChatProvider>
      <ChatLayout />
    </ChatProvider>
  );
}
