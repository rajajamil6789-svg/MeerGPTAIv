import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  X,
  Volume2,
  Sparkles,
  Radio,
  Globe2,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { createSpeechRecognizer, SpeechRecognitionController, speakText, stopSpeaking } from '../utils/speech';

export const VoiceModal: React.FC = () => {
  const { isVoiceModeOpen, setIsVoiceModeOpen, sendMessage, isGenerating, activeConversation, settings } = useChat();

  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [voiceStatus, setVoiceStatus] = useState<'idle' | 'listening' | 'thinking' | 'speaking'>('idle');
  const [voiceLang, setVoiceLang] = useState<'en-US' | 'ur-PK' | 'hi-IN'>('en-US');

  const recognizerRef = useRef<SpeechRecognitionController | null>(null);
  const lastSpokenAssistantId = useRef<string | null>(null);

  // Initialize speech recognition
  useEffect(() => {
    if (!isVoiceModeOpen) {
      recognizerRef.current?.stop();
      stopSpeaking();
      return;
    }

    const recognizer = createSpeechRecognizer(
      (text: string, isFinal: boolean) => {
        setTranscript(text);
        if (isFinal && text.trim().length > 2) {
          // Auto-send voice input
          recognizer.stop();
          setVoiceStatus('thinking');
          sendMessage(text.trim());
          setTranscript('');
        }
      },
      (listening: boolean) => {
        setIsListening(listening);
        if (listening) {
          setVoiceStatus('listening');
        } else if (voiceStatus === 'listening') {
          setVoiceStatus('idle');
        }
      },
      voiceLang
    );

    recognizerRef.current = recognizer;

    // Start listening on open if supported
    if (recognizer.isSupported) {
      recognizer.start();
    }

    return () => {
      recognizer.stop();
      stopSpeaking();
    };
  }, [isVoiceModeOpen, voiceLang]);

  // Monitor assistant response to read aloud
  useEffect(() => {
    if (!isVoiceModeOpen || !activeConversation) return;

    const messages = activeConversation.messages;
    if (messages.length === 0) return;

    const lastMsg = messages[messages.length - 1];

    if (lastMsg.role === 'assistant' && !isGenerating && lastMsg.content && lastMsg.id !== lastSpokenAssistantId.current) {
      lastSpokenAssistantId.current = lastMsg.id;
      setVoiceStatus('speaking');

      speakText(lastMsg.content, {
        rate: settings.speechRate,
        pitch: settings.speechPitch,
        onEnd: () => {
          setVoiceStatus('idle');
          // Resume listening automatically for natural conversation flow
          setTimeout(() => {
            if (recognizerRef.current?.isSupported) {
              recognizerRef.current.start();
            }
          }, 600);
        },
      });
    } else if (isGenerating) {
      setVoiceStatus('thinking');
    }
  }, [isGenerating, activeConversation, isVoiceModeOpen]);

  if (!isVoiceModeOpen) return null;

  const toggleMic = () => {
    if (isListening) {
      recognizerRef.current?.stop();
      setIsListening(false);
      setVoiceStatus('idle');
    } else {
      stopSpeaking();
      recognizerRef.current?.start();
      setIsListening(true);
      setVoiceStatus('listening');
    }
  };

  const handleClose = () => {
    recognizerRef.current?.stop();
    stopSpeaking();
    setIsVoiceModeOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col items-center text-center">
        {/* Close Button */}
        <button
          onClick={handleClose}
          aria-label="Close voice conversation"
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800/80 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Tagline */}
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-medium mb-6">
          <Radio className="w-3.5 h-3.5 animate-pulse text-indigo-400" />
          <span>Real-time Voice Conversation Partner</span>
        </div>

        {/* Voice Language Selector */}
        <div className="flex items-center gap-2 mb-8 bg-slate-800/60 p-1 rounded-xl border border-slate-700/60 text-xs">
          <Globe2 className="w-3.5 h-3.5 text-slate-400 ml-2" />
          <button
            onClick={() => setVoiceLang('en-US')}
            className={`px-3 py-1 rounded-lg transition font-medium ${
              voiceLang === 'en-US' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            English
          </button>
          <button
            onClick={() => setVoiceLang('ur-PK')}
            className={`px-3 py-1 rounded-lg transition font-medium ${
              voiceLang === 'ur-PK' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Urdu / Roman Urdu
          </button>
          <button
            onClick={() => setVoiceLang('hi-IN')}
            className={`px-3 py-1 rounded-lg transition font-medium ${
              voiceLang === 'hi-IN' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Hindi
          </button>
        </div>

        {/* Visualizer Pulsing Orb */}
        <div className="relative my-6 flex items-center justify-center">
          {/* Animated concentric ripples */}
          {voiceStatus === 'listening' && (
            <>
              <div className="absolute w-44 h-44 rounded-full bg-indigo-500/15 animate-ping duration-1000" />
              <div className="absolute w-36 h-36 rounded-full bg-violet-500/20 animate-pulse duration-700" />
            </>
          )}

          {voiceStatus === 'speaking' && (
            <>
              <div className="absolute w-48 h-48 rounded-full bg-emerald-500/15 animate-ping duration-1000" />
              <div className="absolute w-36 h-36 rounded-full bg-teal-500/25 animate-pulse duration-700" />
            </>
          )}

          {voiceStatus === 'thinking' && (
            <div className="absolute w-40 h-40 rounded-full border-2 border-indigo-400/40 border-t-transparent animate-spin" />
          )}

          {/* Central orb */}
          <div
            className={`relative z-10 w-28 h-28 rounded-full flex items-center justify-center shadow-2xl transition-all duration-300 ${
              voiceStatus === 'listening'
                ? 'bg-gradient-to-tr from-indigo-600 to-violet-500 shadow-indigo-500/50 scale-105'
                : voiceStatus === 'speaking'
                ? 'bg-gradient-to-tr from-emerald-600 to-teal-500 shadow-emerald-500/50 scale-105'
                : voiceStatus === 'thinking'
                ? 'bg-gradient-to-tr from-violet-700 to-indigo-800 shadow-violet-500/40'
                : 'bg-gradient-to-tr from-slate-800 to-slate-700 text-slate-300'
            }`}
          >
            {voiceStatus === 'listening' ? (
              <Mic className="w-10 h-10 text-white animate-bounce" />
            ) : voiceStatus === 'speaking' ? (
              <Volume2 className="w-10 h-10 text-white animate-pulse" />
            ) : voiceStatus === 'thinking' ? (
              <Sparkles className="w-9 h-9 text-indigo-300 animate-spin" />
            ) : (
              <MicOff className="w-9 h-9 text-slate-400" />
            )}
          </div>
        </div>

        {/* Status description */}
        <div className="mt-4 mb-3">
          <p className="text-base font-semibold text-white">
            {voiceStatus === 'listening'
              ? 'Listening to you...'
              : voiceStatus === 'speaking'
              ? 'MEER AI is speaking...'
              : voiceStatus === 'thinking'
              ? 'Formulating response...'
              : 'Microphone paused'}
          </p>
          <p className="text-xs text-slate-400 mt-1 max-w-xs">
            {voiceStatus === 'listening'
              ? 'Speak naturally in English, Roman Urdu, or Hindi'
              : voiceStatus === 'speaking'
              ? 'Listen to your AI partner’s response'
              : 'Tap the microphone button below to start'}
          </p>
        </div>

        {/* Live speech transcript card */}
        <div className="w-full min-h-[64px] bg-slate-900/80 border border-slate-800 rounded-2xl p-3 my-4 text-xs text-slate-300 flex items-center justify-center italic">
          {transcript ? (
            <span>&ldquo;{transcript}&rdquo;</span>
          ) : (
            <span className="text-slate-500 not-italic">
              Your voice transcript will appear here in real time...
            </span>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-4 mt-2">
          <button
            onClick={toggleMic}
            className={`flex items-center gap-2 px-6 py-3 rounded-full font-medium text-sm transition-all shadow-lg cursor-pointer ${
              isListening
                ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/30'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
            }`}
          >
            {isListening ? (
              <>
                <MicOff className="w-4 h-4" />
                <span>Pause Mic</span>
              </>
            ) : (
              <>
                <Mic className="w-4 h-4" />
                <span>Start Speaking</span>
              </>
            )}
          </button>

          <button
            onClick={handleClose}
            className="px-5 py-3 rounded-full text-sm font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700/80 transition cursor-pointer"
          >
            Exit Voice
          </button>
        </div>
      </div>
    </div>
  );
};
