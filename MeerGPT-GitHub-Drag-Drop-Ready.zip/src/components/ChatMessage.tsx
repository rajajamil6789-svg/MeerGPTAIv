import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import {
  Copy,
  Check,
  RotateCcw,
  Volume2,
  VolumeX,
  Edit3,
  Bot,
  User,
  Sparkles,
  AlertCircle,
} from 'lucide-react';
import { Message } from '../types';
import { CodeBlock } from './CodeBlock';
import { TypingIndicator } from './TypingIndicator';
import { speakText, stopSpeaking } from '../utils/speech';
import { useChat } from '../context/ChatContext';

interface ChatMessageProps {
  message: Message;
  isLast: boolean;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, isLast }) => {
  const { isGenerating, regenerateResponse, editAndResend, settings } = useChat();

  const [copied, setCopied] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(message.content);

  const isUser = message.role === 'user';

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      console.error('Failed to copy text', e);
    }
  };

  const handleToggleSpeech = () => {
    if (isPlayingAudio) {
      stopSpeaking();
      setIsPlayingAudio(false);
    } else {
      setIsPlayingAudio(true);
      speakText(message.content, {
        rate: settings.speechRate,
        pitch: settings.speechPitch,
        onEnd: () => setIsPlayingAudio(false),
      });
    }
  };

  const handleSaveEdit = async () => {
    if (!editContent.trim()) return;
    setIsEditing(false);
    await editAndResend(message.id, editContent);
  };

  const handleCancelEdit = () => {
    setEditContent(message.content);
    setIsEditing(false);
  };

  const formatTime = (ts: number) => {
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (isUser) {
    return (
      <div className="group flex justify-end mb-6 px-3 sm:px-6 animate-in fade-in duration-200">
        <div className="flex flex-col items-end max-w-[88%] sm:max-w-[78%]">
          {isEditing ? (
            <div className="w-full min-w-[280px] sm:min-w-[440px] bg-slate-800 dark:bg-slate-900 border border-slate-700 rounded-2xl p-3 shadow-xl">
              <textarea
                value={editContent}
                onChange={(e) => setEditContent(e.target.value)}
                rows={3}
                className="w-full bg-slate-900/60 dark:bg-slate-950 text-slate-100 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 border border-slate-700/60 resize-none font-sans"
              />
              <div className="flex justify-end gap-2 mt-2">
                <button
                  onClick={handleCancelEdit}
                  className="px-3 py-1.5 text-xs text-slate-300 hover:text-white rounded-lg hover:bg-slate-700/50 transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveEdit}
                  className="px-3.5 py-1.5 text-xs font-medium bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition shadow-md shadow-indigo-600/30 cursor-pointer"
                >
                  Save & Resend
                </button>
              </div>
            </div>
          ) : (
            <div className="relative">
              <div className="bg-indigo-600 text-white px-4 py-3 rounded-2xl rounded-tr-sm shadow-md text-sm sm:text-[15px] leading-relaxed break-words whitespace-pre-wrap">
                {message.content}
              </div>

              {/* User actions on hover / focus */}
              <div className="flex items-center justify-end gap-1 mt-1 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity text-slate-400 text-xs">
                <span className="text-[11px] text-slate-400 mr-1.5">{formatTime(message.timestamp)}</span>
                <button
                  onClick={() => setIsEditing(true)}
                  disabled={isGenerating}
                  title="Edit message"
                  className="p-1 hover:text-slate-200 hover:bg-slate-800/40 rounded transition cursor-pointer disabled:opacity-40"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={handleCopy}
                  title="Copy text"
                  className="p-1 hover:text-slate-200 hover:bg-slate-800/40 rounded transition cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // If assistant message has no content yet and is currently generating, display TypingIndicator
  if (!message.content && isGenerating && isLast) {
    return <TypingIndicator modelName={settings.model} />;
  }

  // Assistant Message with content
  return (
    <div className="group flex justify-start mb-6 px-3 sm:px-6 animate-in fade-in duration-200">
      <div className="flex gap-3 sm:gap-4 max-w-[94%] sm:max-w-[88%] lg:max-w-[82%]">
        {/* Avatar */}
        <div className="flex-shrink-0 mt-0.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-sky-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 ring-1 ring-white/10">
            <Bot className="w-4 h-4" />
          </div>
        </div>

        {/* Content bubble */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-semibold text-xs text-slate-200 tracking-wide">
              MEER AI
            </span>
            <span className="text-[11px] text-slate-500">
              {formatTime(message.timestamp)}
            </span>
            {isGenerating && isLast && (
              <span className="flex items-center gap-1 text-[11px] text-indigo-400 animate-pulse font-medium">
                <Sparkles className="w-3 h-3" />
                <span>Streaming...</span>
              </span>
            )}
          </div>

          <div className="text-slate-200 dark:text-slate-100 text-sm sm:text-[15px] leading-relaxed break-words bg-slate-900/40 dark:bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 sm:p-5 shadow-sm">
            {message.content && (
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                  code({ node, inline, className, children, ...props }: any) {
                    const match = /language-(\w+)/.exec(className || '');
                    const codeString = String(children).replace(/\n$/, '');

                    if (!inline && (match || codeString.includes('\n'))) {
                      return (
                        <CodeBlock
                          language={match ? match[1] : 'text'}
                          value={codeString}
                        />
                      );
                    }
                    return (
                      <code
                        className="px-1.5 py-0.5 text-xs font-mono rounded bg-slate-800 text-indigo-300 border border-slate-700/60"
                        {...props}
                      >
                        {children}
                      </code>
                    );
                  },
                  p({ children }) {
                    return <p className="mb-3 last:mb-0 leading-relaxed">{children}</p>;
                  },
                  ul({ children }) {
                    return <ul className="list-disc pl-5 mb-3 space-y-1.5 text-slate-300">{children}</ul>;
                  },
                  ol({ children }) {
                    return <ol className="list-decimal pl-5 mb-3 space-y-1.5 text-slate-300">{children}</ol>;
                  },
                  li({ children }) {
                    return <li className="leading-relaxed">{children}</li>;
                  },
                  h1({ children }) {
                    return <h1 className="text-xl sm:text-2xl font-bold text-white mt-4 mb-2 tracking-tight">{children}</h1>;
                  },
                  h2({ children }) {
                    return <h2 className="text-lg sm:text-xl font-semibold text-white mt-3.5 mb-2 tracking-tight">{children}</h2>;
                  },
                  h3({ children }) {
                    return <h3 className="text-base sm:text-lg font-medium text-slate-100 mt-3 mb-1.5">{children}</h3>;
                  },
                  blockquote({ children }) {
                    return (
                      <blockquote className="border-l-4 border-indigo-500/80 pl-3.5 py-1 my-3 italic text-slate-300 bg-indigo-950/20 rounded-r-lg">
                        {children}
                      </blockquote>
                    );
                  },
                  table({ children }) {
                    return (
                      <div className="overflow-x-auto my-3 border border-slate-700/70 rounded-xl">
                        <table className="w-full text-left border-collapse text-xs sm:text-sm">
                          {children}
                        </table>
                      </div>
                    );
                  },
                  thead({ children }) {
                    return <thead className="bg-slate-800/80 text-slate-200 border-b border-slate-700">{children}</thead>;
                  },
                  th({ children }) {
                    return <th className="px-3.5 py-2.5 font-semibold text-slate-200">{children}</th>;
                  },
                  td({ children }) {
                    return <td className="px-3.5 py-2 border-t border-slate-800/60 text-slate-300">{children}</td>;
                  },
                  a({ href, children }) {
                    return (
                      <a
                        href={href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-indigo-400 hover:text-indigo-300 underline underline-offset-2 decoration-indigo-400/40 hover:decoration-indigo-300 transition"
                      >
                        {children}
                      </a>
                    );
                  },
                }}
              >
                {message.content}
              </ReactMarkdown>
            )}

            {/* Blinking typing cursor during active streaming */}
            {isGenerating && isLast && message.content && (
              <span className="inline-block w-2 h-4 ml-1 bg-indigo-400 animate-pulse align-middle rounded-sm" />
            )}

            {/* Error indicator */}
            {message.isError && (
              <div className="mt-3 flex items-center gap-2 text-rose-400 text-xs">
                <AlertCircle className="w-4 h-4" />
                <span>An error occurred while generating this response.</span>
                <button
                  onClick={() => regenerateResponse(message.id)}
                  className="ml-auto underline hover:text-rose-300 font-medium cursor-pointer"
                >
                  Retry
                </button>
              </div>
            )}
          </div>

          {/* Action Toolbar */}
          {!isGenerating && message.content && (
            <div className="flex items-center gap-1 mt-2 text-slate-400 text-xs">
              <button
                onClick={handleCopy}
                title="Copy response"
                className="flex items-center gap-1 px-2 py-1 rounded-md hover:bg-slate-800/70 hover:text-slate-200 transition cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400 text-[11px]">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span className="text-[11px]">Copy</span>
                  </>
                )}
              </button>

              <button
                onClick={handleToggleSpeech}
                title={isPlayingAudio ? 'Stop speaking' : 'Read aloud'}
                className="flex items-center gap-1 px-2 py-1 rounded-md hover:bg-slate-800/70 hover:text-slate-200 transition cursor-pointer"
              >
                {isPlayingAudio ? (
                  <>
                    <VolumeX className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                    <span className="text-rose-400 text-[11px]">Stop</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-3.5 h-3.5" />
                    <span className="text-[11px]">Listen</span>
                  </>
                )}
              </button>

              {isLast && (
                <button
                  onClick={() => regenerateResponse(message.id)}
                  title="Regenerate response"
                  className="flex items-center gap-1 px-2 py-1 rounded-md hover:bg-slate-800/70 hover:text-slate-200 transition cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span className="text-[11px]">Regenerate</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
