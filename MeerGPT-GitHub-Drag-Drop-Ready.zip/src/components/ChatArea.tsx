import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Menu,
  Square,
  ArrowUp,
  Mic,
  MicOff,
  Headphones,
  Settings,
  Sparkles,
  Edit2,
  Check,
  X,
  Plus,
  ArrowDown,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { WelcomeScreen } from './WelcomeScreen';
import { ChatMessage } from './ChatMessage';
import { TypingIndicator } from './TypingIndicator';
import { createSpeechRecognizer, SpeechRecognitionController } from '../utils/speech';

export const ChatArea: React.FC = () => {
  const {
    activeConversation,
    isGenerating,
    sendMessage,
    stopGenerating,
    setIsSidebarOpen,
    setIsSettingsOpen,
    setIsVoiceModeOpen,
    renameConversation,
    createNewChat,
    settings,
  } = useChat();

  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [titleInput, setTitleInput] = useState('');
  const [showScrollBottom, setShowScrollBottom] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const speechRecognizerRef = useRef<SpeechRecognitionController | null>(null);
  const userScrolledUpRef = useRef<boolean>(false);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      textareaRef.current.style.height = Math.min(Math.max(scrollHeight, 44), 180) + 'px';
    }
  }, [input]);

  // Check scroll position to determine if user manually scrolled up
  const handleScroll = useCallback(() => {
    if (!scrollContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
    const distanceFromBottom = scrollHeight - (scrollTop + clientHeight);

    // If user is more than 120px away from bottom, consider them "scrolled up"
    const isUp = distanceFromBottom > 120;
    userScrolledUpRef.current = isUp;
    setShowScrollBottom(isUp);
  }, []);

  const scrollToBottom = useCallback((smooth = true) => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto' });
      userScrolledUpRef.current = false;
      setShowScrollBottom(false);
    }
  }, []);

  // Smart auto-scroll: only scroll automatically if the user hasn't manually scrolled up
  useEffect(() => {
    if (!userScrolledUpRef.current) {
      scrollToBottom(true);
    }
  }, [activeConversation?.messages, isGenerating, scrollToBottom]);

  // Focus textarea when active conversation changes
  useEffect(() => {
    textareaRef.current?.focus();
    userScrolledUpRef.current = false;
    setShowScrollBottom(false);
  }, [activeConversation?.id]);

  const handleSend = async () => {
    if (!input.trim() || isGenerating) return;
    const text = input;
    setInput('');
    if (textareaRef.current) {
      textareaRef.current.style.height = '44px';
    }
    userScrolledUpRef.current = false;
    await sendMessage(text);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const isEnter = e.key === 'Enter';
    if (!isEnter) return;

    if (settings.sendOnEnter) {
      if (!e.shiftKey) {
        e.preventDefault();
        handleSend();
      }
    } else {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        handleSend();
      }
    }
  };

  const toggleDictation = () => {
    if (isRecording) {
      speechRecognizerRef.current?.stop();
      setIsRecording(false);
    } else {
      const recognizer = createSpeechRecognizer(
        (transcript: string) => {
          setInput((prev) => (prev ? prev + ' ' + transcript : transcript));
        },
        (listening: boolean) => {
          setIsRecording(listening);
        },
        'en-US'
      );
      speechRecognizerRef.current = recognizer;
      if (recognizer.isSupported) {
        recognizer.start();
        setIsRecording(true);
      } else {
        alert('Speech recognition is not supported in this browser.');
      }
    }
  };

  const handleSaveTitle = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeConversation && titleInput.trim()) {
      renameConversation(activeConversation.id, titleInput.trim());
    }
    setIsEditingTitle(false);
  };

  const messages = activeConversation?.messages || [];
  // Check if we should display the standalone typing animation indicator
  const lastMessage = messages.length > 0 ? messages[messages.length - 1] : null;
  const isWaitingForFirstToken =
    isGenerating && lastMessage?.role === 'assistant' && !lastMessage.content;

  return (
    <div className="flex-1 flex flex-col h-full bg-[#0a0f1d] text-slate-100 overflow-hidden relative">
      {/* Top Header */}
      <header className="h-14 border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-md px-4 flex items-center justify-between z-20 flex-shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            onClick={() => setIsSidebarOpen((prev) => !prev)}
            aria-label="Toggle navigation drawer"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer md:hidden"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Active Conversation Title */}
          {activeConversation && (
            <div className="flex items-center gap-2 min-w-0">
              {isEditingTitle ? (
                <form onSubmit={handleSaveTitle} className="flex items-center gap-1">
                  <input
                    type="text"
                    value={titleInput}
                    onChange={(e) => setTitleInput(e.target.value)}
                    autoFocus
                    className="bg-slate-900 border border-indigo-500 rounded px-2 py-0.5 text-xs text-white focus:outline-none"
                  />
                  <button type="submit" aria-label="Save title" className="p-1 text-emerald-400 cursor-pointer">
                    <Check className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsEditingTitle(false)}
                    aria-label="Cancel editing title"
                    className="p-1 text-slate-400 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </form>
              ) : (
                <div
                  onClick={() => {
                    setTitleInput(activeConversation.title);
                    setIsEditingTitle(true);
                  }}
                  className="flex items-center gap-1.5 cursor-pointer group min-w-0"
                  title="Click to rename conversation"
                >
                  <span className="font-semibold text-xs sm:text-sm text-slate-200 truncate max-w-[180px] sm:max-w-xs md:max-w-sm">
                    {activeConversation.title}
                  </span>
                  <Edit2 className="w-3 h-3 text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              )}
            </div>
          )}
        </div>

        {/* Header Right Actions */}
        <div className="flex items-center gap-2">
          {/* Active Model Pill */}
          <div className="hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] text-slate-400 font-mono">
            <Sparkles className="w-3 h-3 text-indigo-400" />
            <span>{settings.model || 'gemini-3.8-flash'}</span>
          </div>

          {/* Voice Mode Button */}
          <button
            onClick={() => setIsVoiceModeOpen(true)}
            title="Start Real-time Voice Conversation"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-medium shadow-md shadow-indigo-600/20 transition-all cursor-pointer"
          >
            <Headphones className="w-3.5 h-3.5 animate-pulse" />
            <span className="hidden sm:inline">Voice Partner</span>
          </button>

          <button
            onClick={createNewChat}
            title="New Chat"
            aria-label="New Chat"
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer md:hidden"
          >
            <Plus className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsSettingsOpen(true)}
            aria-label="Settings"
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Messages Scroll Area */}
      <div
        ref={scrollContainerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto px-2 sm:px-4 py-6 scroll-smooth"
      >
        {messages.length === 0 ? (
          <WelcomeScreen />
        ) : (
          <div className="max-w-4xl mx-auto w-full">
            {messages.map((msg, index) => {
              // If this message is the empty assistant message currently being generated,
              // ChatMessage will render the visual typing indicator
              return (
                <ChatMessage
                  key={msg.id}
                  message={msg}
                  isLast={index === messages.length - 1}
                />
              );
            })}

            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Floating "Scroll to latest" button */}
      {showScrollBottom && (
        <button
          onClick={() => scrollToBottom(true)}
          title="Scroll to latest messages"
          className="absolute bottom-28 sm:bottom-24 right-6 z-30 p-2.5 rounded-full bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white border border-slate-700/80 shadow-2xl backdrop-blur-md transition-all animate-bounce cursor-pointer"
        >
          <ArrowDown className="w-4 h-4 text-indigo-400" />
        </button>
      )}

      {/* Floating Stop Generating Button */}
      {isGenerating && (
        <div className="absolute bottom-28 sm:bottom-24 left-1/2 -translate-x-1/2 z-30 animate-in fade-in duration-150">
          <button
            onClick={stopGenerating}
            className="flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900/95 text-slate-200 border border-rose-500/40 hover:border-rose-500/80 hover:bg-rose-950/40 hover:text-white shadow-2xl backdrop-blur-md text-xs font-medium transition cursor-pointer"
          >
            <Square className="w-3 h-3 fill-current text-rose-500 animate-pulse" />
            <span>Stop generating</span>
          </button>
        </div>
      )}

      {/* Input Area */}
      <div className="p-3 sm:p-4 bg-gradient-to-t from-[#0a0f1d] via-[#0a0f1d] to-transparent z-20">
        <div className="max-w-4xl mx-auto w-full">
          {/* Quick Starter Chips on Empty Chat */}
          {messages.length === 0 && (
            <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none text-[11px] text-slate-400">
              <span className="font-semibold text-slate-500 text-[10px] uppercase tracking-wider mr-1">
                Try:
              </span>
              {[
                { label: '🗣️ Roman Urdu Chat', prompt: 'Mujhe Roman Urdu mein guide karein: daily conversational practice shuru karni hai, aap mere sath guftugu karein.' },
                { label: '🎓 Language Partner', prompt: 'Act as my friendly language practice partner. Let’s practice conversational Urdu, Hindi, and English dialogues with vocabulary tips.' },
                { label: '💻 TypeScript Hook', prompt: 'Write a high-performance TypeScript debounce hook with cancellation support and inline comments.' },
                { label: '✍️ Poetic Verse', prompt: 'Write an evocative 4-line poem about evening starlight, followed by its poetic Roman Urdu and Hindi reflections.' },
              ].map((chip, idx) => (
                <button
                  key={idx}
                  onClick={() => sendMessage(chip.prompt)}
                  className="px-2.5 py-1 rounded-lg bg-slate-900/90 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition whitespace-nowrap cursor-pointer flex-shrink-0"
                >
                  {chip.label}
                </button>
              ))}
            </div>
          )}

          {/* Main Input Box */}
          <div className="relative flex items-end gap-2 bg-slate-900/90 border border-slate-800/90 rounded-2xl p-2 sm:p-2.5 shadow-2xl focus-within:border-indigo-500/80 focus-within:ring-1 focus-within:ring-indigo-500/50 transition-all">
            {/* Dictation Mic Button */}
            <button
              type="button"
              onClick={toggleDictation}
              title={isRecording ? 'Stop listening' : 'Dictate with microphone'}
              className={`p-2.5 rounded-xl transition-all cursor-pointer flex-shrink-0 ${
                isRecording
                  ? 'bg-rose-600 text-white animate-pulse shadow-md shadow-rose-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            {/* Expanding Textarea */}
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask MEER AI anything... (English, Roman Urdu, اردو, हिंदी, سنڌي)"
              rows={1}
              className="flex-1 bg-transparent text-slate-100 placeholder-slate-500 text-sm focus:outline-none resize-none py-1.5 px-1 max-h-44 leading-relaxed font-sans"
            />

            {/* Send Button */}
            <button
              type="button"
              onClick={handleSend}
              disabled={!input.trim() || isGenerating}
              aria-label="Send message"
              className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 text-white transition-all shadow-md shadow-indigo-600/25 flex-shrink-0 cursor-pointer disabled:cursor-not-allowed"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>

          {/* Footnote */}
          <div className="flex items-center justify-between px-1 text-[11px] text-slate-500 mt-2 font-medium">
            <span>MEER AI &middot; Your AI. Your Way.</span>
            <span className="hidden sm:inline">
              {settings.sendOnEnter ? 'Press Enter to send, Shift+Enter for new line' : 'Press Ctrl+Enter to send'}
            </span>
            <span className="sm:hidden">Multilingual Fluency</span>
          </div>
        </div>
      </div>
    </div>
  );
};
