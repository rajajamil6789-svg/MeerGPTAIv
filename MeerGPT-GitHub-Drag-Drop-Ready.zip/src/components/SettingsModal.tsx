import React, { useState } from 'react';
import {
  X,
  Sliders,
  Sparkles,
  Volume2,
  Trash2,
  Download,
  Key,
  ShieldCheck,
  Check,
  Globe2,
  Sun,
  Moon,
  Laptop,
  FileCode,
  Info,
  Database,
  CornerDownLeft,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';
import { PersonaType, ThemeMode } from '../types';

export const SettingsModal: React.FC = () => {
  const {
    isSettingsOpen,
    setIsSettingsOpen,
    settings,
    updateSettings,
    theme,
    setTheme,
    clearAllConversations,
    exportConversations,
    exportAsMarkdown,
  } = useChat();

  const [activeTab, setActiveTab] = useState<'general' | 'ai' | 'speech' | 'data' | 'about'>('general');
  const [confirmClear, setConfirmClear] = useState(false);
  const [apiKeyInput, setApiKeyInput] = useState(settings.customApiKey || '');
  const [savedKeySuccess, setSavedKeySuccess] = useState(false);

  if (!isSettingsOpen) return null;

  const handlePersonaChange = (persona: PersonaType) => {
    let defaultPrompt = '';
    if (persona === 'language-tutor') {
      defaultPrompt =
        'You are an expert language partner and conversational tutor. Help me practice conversational Urdu, Hindi, Roman Urdu, and English. In each turn, engage conversationally, and gently point out grammar nuances or vocabulary tips.';
    } else if (persona === 'roman-urdu-expert') {
      defaultPrompt =
        'Aap ek behtareen Roman Urdu conversational expert hain. Jo bhi baat ho, natural aur aam feham Roman Urdu mein jawab dein. Roman Urdu ko jabran English ya formal script mein na badlein.';
    } else if (persona === 'code-expert') {
      defaultPrompt =
        'You are a Principal Software Architect. Provide robust, production-grade code with TypeScript, clean error handling, modular patterns, and clear concise explanations.';
    } else if (persona === 'creative') {
      defaultPrompt =
        'You are a gifted poet, essayist, and creative writer. Use evocative metaphors, poetic rhythm, and rich cultural depth in your responses.';
    }

    updateSettings({
      persona,
      systemInstruction: defaultPrompt,
    });
  };

  const handleSaveApiKey = () => {
    updateSettings({ customApiKey: apiKeyInput.trim() });
    setSavedKeySuccess(true);
    setTimeout(() => setSavedKeySuccess(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/50 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">Settings</h2>
              <p className="text-xs text-slate-400">Configure MEER AI settings & behavior</p>
            </div>
          </div>
          <button
            onClick={() => setIsSettingsOpen(false)}
            aria-label="Close settings"
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-4 py-2 border-b border-slate-800 bg-slate-950/30 overflow-x-auto scrollbar-none flex-shrink-0 text-xs">
          {[
            { id: 'general', label: 'General', icon: Sliders },
            { id: 'ai', label: 'AI Model', icon: Sparkles },
            { id: 'speech', label: 'Voice & Audio', icon: Volume2 },
            { id: 'data', label: 'Data & History', icon: Database },
            { id: 'about', label: 'About', icon: Info },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm text-slate-200">
          {/* GENERAL TAB */}
          {activeTab === 'general' && (
            <div className="space-y-6">
              {/* Theme Selection */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Appearance & Theme
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'dark', label: 'Dark Mode', icon: Moon },
                    { id: 'light', label: 'Light Mode', icon: Sun },
                    { id: 'system', label: 'System Sync', icon: Laptop },
                  ].map((t) => {
                    const Icon = t.icon;
                    const isSelected = theme === t.id;
                    return (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => setTheme(t.id as ThemeMode)}
                        className={`flex items-center justify-center gap-2 p-3 rounded-2xl border text-xs font-medium transition cursor-pointer ${
                          isSelected
                            ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300'
                            : 'bg-slate-800/50 border-slate-700/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        <span>{t.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Language Preference */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Globe2 className="w-4 h-4 text-indigo-400" />
                  <label className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Language Preference
                  </label>
                </div>
                <select
                  value={settings.preferredLanguage}
                  onChange={(e) => updateSettings({ preferredLanguage: e.target.value })}
                  className="w-full bg-slate-800/80 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="auto">Auto-detect (Match User Language automatically)</option>
                  <option value="roman-ur">Roman Urdu (Natural Latin Script)</option>
                  <option value="en">English</option>
                  <option value="ur">Urdu (اردو)</option>
                  <option value="hi">Hindi (हिंदी)</option>
                  <option value="sd">Sindhi (سنڌي)</option>
                </select>
                <p className="text-xs text-slate-500">
                  MEER AI naturally mirrors whatever language you type, including conversational Roman Urdu without forced formal translation.
                </p>
              </div>

              {/* Enter-to-send Behavior */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-800/40 border border-slate-800">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
                    <CornerDownLeft className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Send on Enter</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    {settings.sendOnEnter
                      ? 'Press Enter to send, Shift+Enter for new line'
                      : 'Press Ctrl+Enter or Cmd+Enter to send'}
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.sendOnEnter}
                    onChange={(e) => updateSettings({ sendOnEnter: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>
            </div>
          )}

          {/* AI MODEL TAB */}
          {activeTab === 'ai' && (
            <div className="space-y-6">
              {/* Gemini Model */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Gemini AI Model
                </label>
                <select
                  value={settings.model}
                  onChange={(e) => updateSettings({ model: e.target.value })}
                  className="w-full bg-slate-800/80 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                >
                  <option value="gemini-3.5-flash">gemini-3.5-flash (Recommended · High Quota & Low Latency)</option>
                  <option value="gemini-flash-lite-latest">gemini-flash-lite-latest (Ultra Fast & Responsive)</option>
                  <option value="gemini-3.5-flash-lite">gemini-3.5-flash-lite (Lightweight Flash)</option>
                  <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Stable Flash Lite)</option>
                  <option value="gemini-3.8-flash">gemini-3.8-flash (Preview · 20 RPD Free Quota)</option>
                  <option value="gemini-3.1-pro-preview">gemini-3.1-pro-preview (Deep Reasoning & STEM)</option>
                </select>
              </div>

              {/* Temperature */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold uppercase tracking-wider text-slate-400">
                    Temperature (Creativity)
                  </span>
                  <span className="font-mono text-indigo-400 font-medium">
                    {settings.temperature.toFixed(2)}{' '}
                    {settings.temperature < 0.35
                      ? '(Precise)'
                      : settings.temperature < 0.75
                      ? '(Balanced)'
                      : '(Creative)'}
                  </span>
                </div>
                <input
                  type="range"
                  min="0.0"
                  max="1.0"
                  step="0.05"
                  value={settings.temperature}
                  onChange={(e) => updateSettings({ temperature: parseFloat(e.target.value) })}
                  className="w-full accent-indigo-600 bg-slate-800 h-2 rounded-lg cursor-pointer"
                />
              </div>

              {/* Persona Presets */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Conversational Role & Persona
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'default', label: 'General Assistant' },
                    { id: 'language-tutor', label: 'Language Partner' },
                    { id: 'roman-urdu-expert', label: 'Roman Urdu Expert' },
                    { id: 'code-expert', label: 'Code Architect' },
                    { id: 'creative', label: 'Creative Writer' },
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => handlePersonaChange(p.id as PersonaType)}
                      className={`px-3 py-2 rounded-xl text-xs font-medium border text-left transition cursor-pointer ${
                        settings.persona === p.id
                          ? 'bg-indigo-600/20 border-indigo-500 text-indigo-300'
                          : 'bg-slate-800/50 border-slate-700/60 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom System Instruction */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Custom System Instructions
                </label>
                <textarea
                  rows={3}
                  value={settings.systemInstruction}
                  onChange={(e) => updateSettings({ systemInstruction: e.target.value })}
                  placeholder="e.g. Always respond in Roman Urdu, or provide code samples with clear TypeScript annotations."
                  className="w-full bg-slate-800/80 border border-slate-700/80 rounded-xl p-3 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* API Key Configuration Note */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="flex items-center gap-2">
                  <Key className="w-4 h-4 text-emerald-400" />
                  <label className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Google Gemini API Key
                  </label>
                </div>

                <div className="flex items-center gap-2 p-2.5 bg-emerald-950/20 border border-emerald-500/30 rounded-xl text-xs text-emerald-300">
                  <ShieldCheck className="w-4 h-4 flex-shrink-0" />
                  <span>
                    Verified server-side proxy active with runtime GEMINI_API_KEY environment variable.
                  </span>
                </div>

                <div className="space-y-1.5 mt-2">
                  <span className="text-[11px] text-slate-400">
                    Optional custom API key override (stored locally in browser for testing):
                  </span>
                  <div className="flex gap-2">
                    <input
                      type="password"
                      value={apiKeyInput}
                      onChange={(e) => setApiKeyInput(e.target.value)}
                      placeholder="AIzaSy... (leave empty to use server proxy)"
                      className="flex-1 bg-slate-800/80 border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <button
                      type="button"
                      onClick={handleSaveApiKey}
                      className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-xs font-medium text-slate-200 hover:text-white transition cursor-pointer flex items-center gap-1.5"
                    >
                      {savedKeySuccess ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Saved</span>
                        </>
                      ) : (
                        <span>Save Key</span>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SPEECH TAB */}
          {activeTab === 'speech' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-800/40 border border-slate-800">
                <div className="space-y-0.5">
                  <span className="text-xs font-semibold text-slate-200">
                    Auto-read AI responses aloud
                  </span>
                  <p className="text-xs text-slate-400">
                    Automatically speak every new assistant response via Web Speech synthesis
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.autoSpeak}
                    onChange={(e) => updateSettings({ autoSpeak: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5 p-3 rounded-2xl bg-slate-800/30 border border-slate-800">
                  <div className="flex justify-between text-xs text-slate-300">
                    <span>Speech Speed</span>
                    <span className="font-mono text-indigo-400 font-semibold">{settings.speechRate.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.7"
                    max="1.5"
                    step="0.1"
                    value={settings.speechRate}
                    onChange={(e) => updateSettings({ speechRate: parseFloat(e.target.value) })}
                    className="w-full accent-indigo-600 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
                  />
                </div>

                <div className="space-y-1.5 p-3 rounded-2xl bg-slate-800/30 border border-slate-800">
                  <div className="flex justify-between text-xs text-slate-300">
                    <span>Speech Pitch</span>
                    <span className="font-mono text-indigo-400 font-semibold">{settings.speechPitch.toFixed(1)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.8"
                    max="1.2"
                    step="0.05"
                    value={settings.speechPitch}
                    onChange={(e) => updateSettings({ speechPitch: parseFloat(e.target.value) })}
                    className="w-full accent-indigo-600 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}

          {/* DATA TAB */}
          {activeTab === 'data' && (
            <div className="space-y-6">
              <div className="space-y-3">
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Export Conversations
                </label>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={exportConversations}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 hover:text-white transition cursor-pointer border border-slate-700"
                  >
                    <Download className="w-4 h-4 text-indigo-400" />
                    <span>Export All as JSON</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => exportAsMarkdown()}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 hover:text-white transition cursor-pointer border border-slate-700"
                  >
                    <FileCode className="w-4 h-4 text-emerald-400" />
                    <span>Export Active Chat as Markdown (.md)</span>
                  </button>
                </div>
              </div>

              {/* Clear Conversations with Confirmation */}
              <div className="pt-4 border-t border-slate-800 space-y-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-rose-400">
                  Danger Zone
                </label>

                {confirmClear ? (
                  <div className="p-4 rounded-2xl bg-rose-950/30 border border-rose-800/60 space-y-3">
                    <p className="text-xs text-rose-300 font-medium">
                      Are you sure you want to permanently delete all conversations? This action cannot be undone.
                    </p>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          clearAllConversations();
                          setConfirmClear(false);
                          setIsSettingsOpen(false);
                        }}
                        className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-medium transition cursor-pointer shadow-md shadow-rose-600/30"
                      >
                        Yes, Delete All Conversations
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmClear(false)}
                        className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs transition cursor-pointer"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setConfirmClear(true)}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-rose-400 hover:text-white hover:bg-rose-600 transition text-xs font-medium border border-rose-800/50 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Clear All Conversations</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* ABOUT TAB */}
          {activeTab === 'about' && (
            <div className="space-y-4 text-center py-2">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-sky-400 mx-auto flex items-center justify-center text-white shadow-xl shadow-indigo-600/30">
                <Sparkles className="w-8 h-8" />
              </div>

              <div>
                <h3 className="text-xl font-bold text-white tracking-tight">MEER AI</h3>
                <p className="text-xs text-indigo-400 font-semibold mt-0.5">Your AI. Your Way.</p>
                <span className="inline-block mt-2 px-2.5 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-[11px] font-mono text-slate-400">
                  Version 3.8.0
                </span>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                MEER AI is a modern AI assistant designed for natural conversations, productivity, learning, coding, and everyday questions.
              </p>

              <div className="pt-4 border-t border-slate-800 max-w-sm mx-auto text-left text-xs text-slate-400 space-y-1.5">
                <div className="flex justify-between">
                  <span>Engine:</span>
                  <span className="font-mono text-slate-200">Google Gemini 3 SDK</span>
                </div>
                <div className="flex justify-between">
                  <span>Multilingual:</span>
                  <span className="text-slate-200">English, Roman Urdu, Urdu, Hindi, Sindhi</span>
                </div>
                <div className="flex justify-between">
                  <span>Streaming:</span>
                  <span className="text-emerald-400">SSE Active</span>
                </div>
                <div className="flex justify-between">
                  <span>Storage:</span>
                  <span className="text-slate-200">Encrypted / LocalStorage</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
