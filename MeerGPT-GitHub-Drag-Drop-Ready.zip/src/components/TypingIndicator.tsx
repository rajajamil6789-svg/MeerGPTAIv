import React from 'react';
import { Bot, Sparkles } from 'lucide-react';

interface TypingIndicatorProps {
  statusText?: string;
  modelName?: string;
}

export const TypingIndicator: React.FC<TypingIndicatorProps> = ({
  statusText = 'MEER AI is thinking...',
  modelName = 'gemini-flash-lite-latest',
}) => {
  return (
    <div className="flex justify-start mb-6 px-3 sm:px-6 animate-in fade-in duration-300">
      <div className="flex gap-3 sm:gap-4 max-w-[94%] sm:max-w-[88%] lg:max-w-[82%]">
        {/* Assistant Avatar with glowing aura */}
        <div className="flex-shrink-0 mt-0.5 relative">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-sky-400 flex items-center justify-center text-white shadow-md shadow-indigo-500/25 ring-1 ring-white/10 animate-pulse">
            <Bot className="w-4 h-4" />
          </div>
          <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 rounded-full ring-2 ring-slate-950 animate-ping" />
          <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 rounded-full ring-2 ring-slate-950" />
        </div>

        {/* Content bubble */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="font-semibold text-xs text-slate-200 tracking-wide">
              MEER AI
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 font-mono">
              {modelName}
            </span>
          </div>

          <div className="inline-flex items-center gap-3 px-4 py-3 bg-slate-900/70 dark:bg-slate-900/80 border border-slate-800/80 rounded-2xl rounded-tl-sm shadow-lg backdrop-blur-sm">
            {/* Visual Typing Animation Dots */}
            <div className="flex items-center gap-1.5 py-1">
              <span
                className="w-2.5 h-2.5 rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 animate-bounce shadow-sm shadow-indigo-500/50"
                style={{ animationDelay: '0ms', animationDuration: '900ms' }}
              />
              <span
                className="w-2.5 h-2.5 rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-500 animate-bounce shadow-sm shadow-violet-500/50"
                style={{ animationDelay: '180ms', animationDuration: '900ms' }}
              />
              <span
                className="w-2.5 h-2.5 rounded-full bg-gradient-to-r from-fuchsia-500 to-sky-400 animate-bounce shadow-sm shadow-sky-500/50"
                style={{ animationDelay: '360ms', animationDuration: '900ms' }}
              />
            </div>

            {/* Status text */}
            <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium border-l border-slate-800 pl-3">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-spin" style={{ animationDuration: '3s' }} />
              <span className="animate-pulse">{statusText}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
