import React from 'react';
import {
  Feather,
  Atom,
  Code2,
  FileText,
  Lightbulb,
  GraduationCap,
  Sparkles,
  Globe2,
} from 'lucide-react';
import { useChat } from '../context/ChatContext';

export const WelcomeScreen: React.FC = () => {
  const { sendMessage } = useChat();

  const suggestionCards = [
    {
      icon: Feather,
      title: 'Write a poem',
      desc: 'Soulful verses with Roman Urdu, Urdu, or English reflections.',
      prompt: 'Write an evocative 4-line poem about evening starlight, followed by its poetic Roman Urdu and Hindi reflections.',
      accent: 'from-purple-500/20 to-pink-500/20 border-purple-500/30 text-purple-400',
    },
    {
      icon: Atom,
      title: 'Explain quantum physics',
      desc: 'Complex concepts simplified through clear intuitive analogies.',
      prompt: 'Explain quantum entanglement and superposition using an intuitive coin-flip or library metaphor.',
      accent: 'from-cyan-500/20 to-blue-500/20 border-cyan-500/30 text-cyan-400',
    },
    {
      icon: Code2,
      title: 'Help me code',
      desc: 'Clean, idiomatic TypeScript, React, and full-stack solutions.',
      prompt: 'Write a high-performance TypeScript debounce hook with cancellation support and inline comments.',
      accent: 'from-amber-500/20 to-orange-500/20 border-amber-500/30 text-amber-400',
    },
    {
      icon: FileText,
      title: 'Summarize something',
      desc: 'Distill articles, documents, and notes into executive bullet points.',
      prompt: 'Summarize the key architectural benefits of reactive streams and event-driven architecture into clear key takeaways.',
      accent: 'from-emerald-500/20 to-teal-500/20 border-emerald-500/30 text-emerald-400',
    },
    {
      icon: Lightbulb,
      title: 'Brainstorm ideas',
      desc: 'Fresh creative angles for apps, startups, and creative campaigns.',
      prompt: 'Brainstorm 5 innovative product ideas combining real-time voice AI and language immersion learning.',
      accent: 'from-yellow-500/20 to-amber-500/20 border-yellow-500/30 text-yellow-400',
    },
    {
      icon: GraduationCap,
      title: 'Learn something new',
      desc: 'Interactive language practice in Roman Urdu, Hindi, or English.',
      prompt: 'Mujhe Roman Urdu mein guide karein: daily conversational practice shuru karni hai, aap mere sath guftugu karein aur tips dein.',
      accent: 'from-indigo-500/20 to-violet-500/20 border-indigo-500/30 text-indigo-400',
    },
  ];

  return (
    <div className="flex flex-col items-center justify-center min-h-full px-4 py-8 max-w-4xl mx-auto text-center">
      {/* Brand Hero */}
      <div className="relative mb-5">
        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-sky-400 flex items-center justify-center text-white shadow-2xl shadow-indigo-500/30 ring-1 ring-white/20 animate-pulse">
          <Sparkles className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
        </div>
      </div>

      <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-2">
        Hello, I&apos;m{' '}
        <span className="bg-gradient-to-r from-indigo-400 via-violet-300 to-sky-400 bg-clip-text text-transparent">
          MEER AI
        </span>
      </h1>

      <p className="text-lg sm:text-xl text-slate-200 dark:text-slate-300 font-semibold mb-2">
        How can I help you today?
      </p>

      <p className="text-xs sm:text-sm text-slate-400 font-medium mb-3">
        Your AI. Your Way.
      </p>

      {/* Multilingual strip */}
      <div className="flex flex-wrap items-center justify-center gap-2 text-xs text-slate-400 mb-8 max-w-xl">
        <span className="flex items-center gap-1.5 text-indigo-400 font-medium">
          <Globe2 className="w-3.5 h-3.5" />
          Multilingual Fluency:
        </span>
        <span>English</span>
        <span aria-hidden="true">&middot;</span>
        <span className="font-medium text-indigo-300">Roman Urdu</span>
        <span aria-hidden="true">&middot;</span>
        <span className="font-urdu">اردو</span>
        <span aria-hidden="true">&middot;</span>
        <span className="font-hindi">हिंदी</span>
        <span aria-hidden="true">&middot;</span>
        <span className="font-sindhi">سنڌي</span>
      </div>

      {/* Suggestion Cards Grid (6 cards) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 w-full text-left">
        {suggestionCards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <button
              key={idx}
              onClick={() => sendMessage(card.prompt)}
              className="group relative flex flex-col p-4 sm:p-5 rounded-2xl bg-slate-900/60 dark:bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800/80 hover:border-slate-700/80 transition-all duration-200 text-left shadow-lg hover:shadow-indigo-500/5 hover:-translate-y-0.5 cursor-pointer"
            >
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 bg-gradient-to-br ${card.accent} border`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <h3 className="font-semibold text-sm sm:text-[15px] text-slate-100 group-hover:text-indigo-300 transition-colors mb-1">
                {card.title}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">
                {card.desc}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
};
