// Speech synthesis and recognition utility for MEER AI

let currentAudio: HTMLAudioElement | null = null;

export function stopSpeaking() {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
  if (currentAudio) {
    currentAudio.pause();
    currentAudio.currentTime = 0;
    currentAudio = null;
  }
}

export function isSpeaking(): boolean {
  if (currentAudio && !currentAudio.paused) return true;
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    return window.speechSynthesis.speaking;
  }
  return false;
}

export function speakText(
  text: string,
  options: {
    rate?: number;
    pitch?: number;
    lang?: string;
    onStart?: () => void;
    onEnd?: () => void;
  } = {}
) {
  stopSpeaking();
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    options.onEnd?.();
    return;
  }

  // Clean text from markdown code blocks or symbols
  const cleanText = text
    .replace(/```[\s\S]*?```/g, 'Code block omitted.')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/[#*_~>]/g, '')
    .trim();

  if (!cleanText) {
    options.onEnd?.();
    return;
  }

  const utterance = new SpeechSynthesisUtterance(cleanText);
  utterance.rate = options.rate ?? 1.0;
  utterance.pitch = options.pitch ?? 1.0;

  // Auto-detect or use language
  if (options.lang) {
    utterance.lang = options.lang;
  } else {
    // Check if contains Urdu or Hindi script
    const hasUrduArabic = /[\u0600-\u06FF]/.test(cleanText);
    const hasDevanagari = /[\u0900-\u097F]/.test(cleanText);
    if (hasUrduArabic) {
      utterance.lang = 'ur-PK';
    } else if (hasDevanagari) {
      utterance.lang = 'hi-IN';
    } else {
      utterance.lang = 'en-US';
    }
  }

  // Attempt to select the best available voice
  const voices = window.speechSynthesis.getVoices();
  const matchedVoice = voices.find((v) => v.lang.startsWith(utterance.lang.slice(0, 2)));
  if (matchedVoice) {
    utterance.voice = matchedVoice;
  }

  utterance.onstart = () => {
    options.onStart?.();
  };

  utterance.onend = () => {
    options.onEnd?.();
  };

  utterance.onerror = () => {
    options.onEnd?.();
  };

  window.speechSynthesis.speak(utterance);
}

// Speech Recognition helper
export interface SpeechRecognitionController {
  start: () => void;
  stop: () => void;
  isSupported: boolean;
}

export function createSpeechRecognizer(
  onResult: (transcript: string, isFinal: boolean) => void,
  onStateChange: (listening: boolean) => void,
  lang: string = 'en-US'
): SpeechRecognitionController {
  if (typeof window === 'undefined') {
    return { start: () => {}, stop: () => {}, isSupported: false };
  }

  const SpeechRecognition =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

  if (!SpeechRecognition) {
    return { start: () => {}, stop: () => {}, isSupported: false };
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = lang;

  let isListening = false;

  recognition.onstart = () => {
    isListening = true;
    onStateChange(true);
  };

  recognition.onresult = (event: any) => {
    let interimTranscript = '';
    let finalTranscript = '';

    for (let i = event.resultIndex; i < event.results.length; ++i) {
      const piece = event.results[i][0].transcript;
      if (event.results[i].isFinal) {
        finalTranscript += piece;
      } else {
        interimTranscript += piece;
      }
    }

    const currentTranscript = finalTranscript || interimTranscript;
    if (currentTranscript.trim()) {
      onResult(currentTranscript, Boolean(finalTranscript));
    }
  };

  recognition.onerror = (err: any) => {
    console.warn('Speech recognition error:', err);
    isListening = false;
    onStateChange(false);
  };

  recognition.onend = () => {
    isListening = false;
    onStateChange(false);
  };

  return {
    isSupported: true,
    start: () => {
      try {
        if (!isListening) {
          recognition.start();
        }
      } catch (err) {
        console.warn('Error starting speech recognition:', err);
      }
    },
    stop: () => {
      try {
        if (isListening) {
          recognition.stop();
        }
      } catch (err) {
        console.warn('Error stopping speech recognition:', err);
      }
    },
  };
}
